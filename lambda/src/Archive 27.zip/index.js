////////////////////////////////
//EXTERNAL IMPORTS
////////////////////////////////
const Alexa = require('alexa-sdk');
const request = require('request');
const https = require('https');

////////////////////////////////
// Global Variables
////////////////////////////////
var clearHours = [];
var notClearHours = [];
var alexaClearHours = [];
var alexaNotClearHours = [];
var conditionAtTime;
var justHour;
var totalHoursNightCount = 0;
var clearConditionsHourCount = 0;

//---FUNCTIONS TO CHANGE MAKE HOURS READABLE FOR ALEXA--
//======================================================
//---------------makes hour readable by alexa-----------
var clearNotClearPrep = function(){
//a function to return a single or double digit only for time
    for (var i = 0; i < clearHours.length; i++) {
        //iterate through all clear hours of the night
        var splitHour = clearHours[i].split(":");
        //splits the hour from the minute at ":"
        var justHour = splitHour[0];
        //grabs the first index, the hour
        makeItAMPM(justHour);
        //sends justHour to makeItAMPM to remove military time and add "am" or "pm"
        alexaClearHours.push(justHour);
        //pushes the readable hour to alexaClearHours array
    };
    for (var i = 0; i < notClearHours.length; i++) {
        var splitHour = notClearHours[i].split(":");
        var justHour = splitHour[0];
        makeItAMPM(justHour);
        alexaNotClearHours.push(justHour);
    };
};
//------------------converts military time------------
var makeItAMPM = function(justHour){
    if(justHour > 12){
        justHour = justHour - 12 + "pm";
    } else {
        if(justHour < 10 || justHour == 0){
            justHour = justHour.split("");
            justHour = justHour.splice(1, 1);
            if(justHour == 0){
                justHour = "midnight";
            } else {
                justHour = justHour + "am"
            };
        };
    };
};
//-------------adds an "and" before last item-------
var addAnd = function(array){
    if(array.length > 1){
        index = array.length - 1;
        array.splice(index, 0, "and");
    };
};
//separate the clear hours of the night from the not clear hours of the night
var getClearHours = function(arr1, arr2){
    for (var i = 0; i < arr1.length; i++) {
        var forecastTime = arr1[i].time;
        var acceptIt = function(){
            var breakUpDateTime = forecastTime.split(" ");
            var breakUpHourMin = breakUpDateTime[1].split(":");
            var getHour = breakUpHourMin[0];
            if(getHour > 15){
                return true;
            };
        };
        if( (arr1[i].is_day == 0) && (acceptIt()) ){
            totalHoursNightCount++;
            if(arr1[i].condition.text != 'Clear' ){
                var timeArray = arr1[i].time.split(" ");
                notClearHours.push(timeArray[1]);
            } else if(arr1[i].condition.text == 'Clear'){
                clearConditionsHourCount++;
                var timeArray = arr1[i].time.split(" ");
                clearHours.push(timeArray[1]);
            };
        };
    };
    for (var i = 0; i < arr2.length; i++) {
        var forecastTime = arr2[i].time;
        var acceptIt = function(){
            var breakUpDateTime = forecastTime.split(" ");
            var breakUpHourMin = breakUpDateTime[1].split(":");
            var getHour = breakUpHourMin[0];
            if(getHour < 9){
                return true;
            };
        };
        if( (arr2[i].is_day == 0) && (acceptIt()) ){
            totalHoursNightCount++;
            if(arr2[i].condition.text != 'Clear' ){
                var timeArray = arr2[i].time.split(" ");
                notClearHours.push(timeArray[1]);
            } else if(arr2[i].condition.text == 'Clear'){
                clearConditionsHourCount++;
                var timeArray = arr2[i].time.split(" ");
                clearHours.push(timeArray[1]);
            };
        };
    };
};

////////////////////////////////
// SKILL CONSTANTS
////////////////////////////////
var APP_ID = 'amzn1.ask.skill.92a24c78-c2ca-410f-aa76-9ea83c7dcf55';//Application ID here from Dev Portal
var SKILL_NAME = "Star Gazer";//Skill Name Goes here
var WELCOME_MESSAGE = "I love to gaze at the stars. Tell me your zipcode so I can see if the weather is good in your area for star gazing.";
var HELP_MESSAGE = "You can ask if the weather good for star gazing in a certain zipcode, or, you can say exit... What can I help you with?";
var HELP_REPROMPT = "When would you like to see the stars?";
var STOP_MESSAGE = "Happy gazing! Goodbye!";
var WRONG_MESSAGE = "Went to unhandled"


////////////////////////////////
//============================//
// HANDLER CODE
//============================//
////////////////////////////////
exports.handler = function(event, context, callback){
    var alexa = Alexa.handler(event, context, callback);
    alexa.appId = 'amzn1.ask.skill.92a24c78-c2ca-410f-aa76-9ea83c7dcf55';
    alexa.registerHandlers(handlers);//separate multiple handlers by ','
    alexa.execute();
};

/////////////////////////////////
//INTENT HANDLERS
/////////////////////////////////
var handlers = {
    'LaunchRequest': function () {
        var speechOutput = WELCOME_MESSAGE;
        var reprompt = HELP_REPROMPT;
        this.emit(':ask', speechOutput, reprompt);
    },
    'Unhandled': function () {
        this.emit(':ask', WRONG_MESSAGE);
    },
    'GetZipcodeIntent': function (event) {
        var zipcode = this.event.request.intent.slots.Zipcode.value;
        this.attributes['zipcode'] = zipcode;
        this.emit(':ask', "What would you like to know? You can ask, Is the weather good for star gazing? or Can I star gaze at eleven pm");
    },
    'GetWeatherDateIntent': function () {
        this.emit(':tell', "I'm still learning how to get the weather by a future date.");
        var date = this.event.request.intent.slots.Date.value;
        var myRequest = this.event.request.intent.slots;
        var zipcode = '';
        if (this.attributes['zipcode']) {
            zipcode = this.attributes['zipcode'];
        }

    },
    'GetWeatherTimeIntent': function () {
        var time = this.event.request.intent.slots.Time.value;
        var zipcode = '';
        if (this.attributes['zipcode']) {
            zipcode = this.attributes['zipcode'];
        };
        var myRequest = this.event.request.intent.slots;

        //--------CHECK REQUEST FOR SPECIFIC TIME---------
        if(time.length > 0){
            httpsGetCurrent ( myRequest,  (myResult) => {
            // console.log("sent from Time        : ", myRequest);
            // console.log("received back for Time: ", myResult);

                var isDay = myResult.current.is_day;
                var byHourToday = myResult.forecast.forecastday[0].hour;
                var byHourTomorrow = myResult.forecast.forecastday[1].hour;
                var sunset = myResult.forecast.forecastday[0].astro.sunset;

                if (clearHours.length == 0 && notClearHours.length == 0){
                    getClearHours(byHourToday, byHourTomorrow);
                    clearNotClearPrep();
                    addAnd(alexaClearHours);
                    addAnd(alexaNotClearHours);//checks for a time from request
                    console.log("alexa not clear " + alexaNotClearHours);
                    console.log("alexa clear " + alexaClearHours);
                    console.log("clearHours " + clearHours);
                    console.log("notClearHours " + notClearHours);
                };
                for (var i = 0; i < byHourToday.length; i++) {
                    console.log(byHourToday[i].time.includes(time));
                    if(byHourToday[i].time.includes(time)){
                        console.log("request vs i " + time + byHourToday[i].time);
                        if(byHourToday[i].is_day == 0){
                            this.emit(':tell', "At " + time + " the weather condition is forecasted as " + byHourToday[i].condition.text);
                        } else if(byHourToday[i].is_day == 1){
                            this.emit(':tell', "The hour you requested is a day time hour. You can try an hour past " + sunset);
                        };
                    };
                }
            });
        } else {
            console.log("no time given");
        };
    },
    'GetWeatherTodayIntent': function (event) {
        //-------------------Variables-------------------
        var zipcode = this.event.request.intent.slots.Zipcode.value;
        this.attributes['zipcode'] = zipcode;
        var myRequest = this.event.request.intent.slots;

        //////////////////////////////////////////////////////
        //------------BEGINNING OF CONDITIONALS---------------
        //////////////////////////////////////////////////////

        if (zipcode.length > 0){
            //-------------------GET REQUEST---------------------
            httpsGetCurrent ( myRequest,  (myResult) => {
                // console.log("sent     : ", myRequest);
                // console.log("received : ", myResult);
                //----------HTTP REQUEST DEPENDENT-VARIABLES---------
                var city = myResult.location.name;
                var weatherCondition = myResult.current.condition.text;
                var localTime = myResult.location.localtime;
                var isDay = myResult.current.is_day;
                var sunset = myResult.forecast.forecastday[0].astro.sunset
                var byHourToday = myResult.forecast.forecastday[0].hour;
                var byHourTomorrow = myResult.forecast.forecastday[1].hour;
                //----------------------------------------------------
                //calling functions to prep for output speech to Alexa
                //----------------------------------------------------
                getClearHours(byHourToday, byHourTomorrow);
                clearNotClearPrep();
                addAnd(alexaClearHours);
                addAnd(alexaNotClearHours);//checks for a time from request
                // console.log("alexa not clear " + alexaNotClearHours);
                // console.log("alexa clear " + alexaClearHours);
                // console.log("clearHours " + clearHours);
                // console.log("notClearHours " + notClearHours);

                //-------------------CONDITIONALS---------------------
                //----------------AND OUTPUTS-SPEECH------------------
                if(isDay == 1){
                    if(clearConditionsHourCount/ totalHoursNightCount == 1){
                        this.emit(':tell', "It's currently isDay in " + city + " but it will be clear all night tonight starting at sunset around " + sunset + ".");
                    } else if (clearConditionsHourCount == 0){
                        this.emit(':tell', "It's currently isDay in " + city + ". Tonight will be cloudy. Ask me to check the forecast for another day.");
                    } else if (clearHours.length <= notClearHours.length){
                        this.emit(':tell', "It's currently isDay in " + city + " Tonight, you will have the highest chance of seeing the stars at " + alexaClearHours);
                    } else if (clearHours.length > notClearHours.length){
                        this.emit(':tell', "It's currently isDay in " + city + ". Tonight, it will be mostly clear. It will be difficult to see the stars at " + alexaNotClearHours);
                    };
                } else if(isDay == 0){
                    if(clearConditionsHourCount/ totalHoursNightCount == 1){
                        this.emit(':tell', "It will be clear all night tonight.");
                    } else if (clearConditionsHourCount == 0){
                        this.emit(':tell', "Tonight will be cloudy. Ask me to check the forecast for another day. ");
                    } else if (clearHours.length <= notClearHours.length){
                        this.emit(':tell', "You will have the highest chance of star gazing at " + alexaClearHours);
                    } else if (clearHours.length > notClearHours.length){
                        this.emit(':tell', "It will be mostly clear tonight. You're least likely to see the stars at " + alexaNotClearHours);
                    };
                };
            });
        } else if(zipcode.length == 0){
            this.emit(':ask', 'What is your Zipcode?');
        };
    },
    'AMAZON.HelpIntent': function (req, res) {
        console.log(req);
        var speechOutput = HELP_MESSAGE;
        var reprompt = HELP_REPROMPT;
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function (req, res) {
        console.log(req);
        this.emit(':tell', STOP_MESSAGE);
    },
    'AMAZON.StopIntent': function (req, res) {
        console.log(req);
        this.emit(':tell', STOP_MESSAGE);
    }
};
//---------------End of Handlers---------------------

/////////////////////////////////////////////////////
//===================================================
// HTTP GET REQUEST FUNCTIONS
//===================================================
/////////////////////////////////////////////////////
var apiKey = '6deb7aeace39475b96d191651172505'
var httpsGetCurrent = function (myData, callback) {

    // Update these options with the details of the web service you would like to call
    console.log('zipcode in request = ', myData.Zipcode.value);
    var options = {
        host: 'api.apixu.com',
        port: 443,
        path: '/v1/forecast.json?key=' + apiKey +'&q=' + encodeURIComponent(myData.Zipcode.value) + '&days=5',
        method: 'GET'
    };

    var req = https.request(options, res => {
        res.setEncoding('utf8');
        var returnData = "";


        res.on('data', chunk => {

            returnData = returnData + chunk;
            // console.log("return data from API" + returnData);
        });

        res.on('end', () => {

            var pop = JSON.parse(returnData);
            // console.log(pop);
            // console.log("pop", pop.current.condition.text);

            callback(pop);  // this will execute whatever function the caller defined, with one argument

        });

    });
    req.end();

};

//     if (notClearHours[i] == time){
//         conditionAtTime = "not clear";
//         console.log('n conditionAtTime' + conditionAtTime);
//     } else {
//         for (var j = 0; j < clearHours.length; j++) {
//             if (clearHours[j] == time){
//                 conditionsAtTime = "clear";
//                 console.log('c conditionAtTime' + conditionAtTime);
//             };
//         };
//     };
//     console.log('conditionAtTime' + conditionAtTime);
